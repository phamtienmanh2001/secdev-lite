# SCA summary
{
  "Medium": 3
}
